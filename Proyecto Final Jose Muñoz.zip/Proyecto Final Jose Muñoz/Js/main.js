let carrito = [];
let productosGlobal = [];

/* =========================
   ELEMENTOS DEL DOM
========================= */

const modal = document.getElementById("modalCarrito");
const btnCarrito = document.getElementById("btnCarrito");
const cerrar = document.querySelector(".cerrar");

const contenedorCarrito = document.getElementById("contenidoCarrito");
const totalHTML = document.getElementById("totalCarrito");
const contadorCarrito = document.getElementById("contadorCarrito");
const btnFinalizar = document.getElementById("btnFinalizar");
const btnVaciar = document.getElementById("btnVaciar");


/* =========================
   CARGAR PRODUCTOS
========================= */

fetch("../data/productos.json")
    .then(res => res.json())
    .then(data => {
        productosGlobal = data;
        mostrarProductos(productosGlobal);
    });


function mostrarProductos(productos) {

    const contenedor = document.getElementById("contenedorProductos");
    contenedor.innerHTML = "";

    productos.forEach(producto => {

        const card = document.createElement("div");
        card.className = "card";

        card.innerHTML = `
            <img src="${producto.imagen}">
            <h3>${producto.nombre}</h3>
            <p>$${producto.precio}</p>
         <p class="stock">
    Stock disponible:
    <span id="stock-${producto.id}">
        ${producto.stock > 0 ? producto.stock : "Sin stock"}
    </span>
</p>

            <button id="btn-${producto.id}">
                ${producto.stock === 0 ? "Sin stock" : "Agregar"}
            </button>
        `;

        const boton = card.querySelector("button");

        if (producto.stock === 0) {
            boton.disabled = true;
        } else {
            boton.addEventListener("click", () => agregarAlCarrito(producto.id));
        }

        contenedor.appendChild(card);
    });
}


/* =========================
   FUNCIONES DEL CARRITO
========================= */

function agregarAlCarrito(id) {

    const producto = productosGlobal.find(p => p.id === id);

    if (producto.stock <= 0) return;

    producto.stock--;

    const existe = carrito.find(p => p.id === id);

    if (existe) {
        existe.cantidad++;
    } else {
        carrito.push({ ...producto, cantidad: 1 });
    }

    actualizarContador();
    actualizarStockVisual(id);
}


function eliminarProducto(id) {

    const productoCarrito = carrito.find(p => p.id === id);
    const productoGlobal = productosGlobal.find(p => p.id === id);

    if (productoCarrito.cantidad > 1) {
        productoCarrito.cantidad--;
        productoGlobal.stock++;
    } else {
        productoGlobal.stock++;
        carrito = carrito.filter(p => p.id !== id);
    }

    actualizarContador();
    actualizarStockVisual(id);
    mostrarCarrito();
}


function actualizarContador() {
    const total = carrito.reduce((acc, p) => acc + p.cantidad, 0);
    contadorCarrito.textContent = total;
}


function actualizarStockVisual(id) {

    const producto = productosGlobal.find(p => p.id === id);

    const stockSpan = document.getElementById(`stock-${id}`);
    const boton = document.getElementById(`btn-${id}`);

    stockSpan.textContent = producto.stock;

    if (producto.stock === 0) {
        boton.textContent = "Sin stock";
        boton.disabled = true;
        stockSpan.style.color = "red";
    } else {
        boton.textContent = "Agregar";
        boton.disabled = false;
        stockSpan.style.color = "limegreen";
    }
}


/* =========================
   MOSTRAR CARRITO
========================= */

function mostrarCarrito() {

    contenedorCarrito.innerHTML = "";

    if (carrito.length === 0) {

        contenedorCarrito.innerHTML = `
            <p style="text-align:center; font-family: 'Orbitron', sans-serif;">
                El carrito está vacío
            </p>
        `;

        totalHTML.textContent = "";

    } else {

        carrito.forEach(prod => {

            const div = document.createElement("div");

            div.innerHTML = `
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                    <span>${prod.nombre} x${prod.cantidad}</span>
                    <span>$${prod.precio * prod.cantidad}</span>
                    <button onclick="eliminarProducto(${prod.id})">➖</button>
                </div>
            `;

            contenedorCarrito.appendChild(div);
        });

        const total = carrito.reduce((acc, p) => acc + p.precio * p.cantidad, 0);
        totalHTML.textContent = "Total: $" + total;
    }

    modal.style.display = "flex";
}


/* =========================
   EVENTOS
========================= */

btnCarrito.addEventListener("click", mostrarCarrito);

cerrar.addEventListener("click", () => {
    modal.style.display = "none";
});


btnFinalizar.addEventListener("click", () => {

    if (carrito.length === 0) {
        contenedorCarrito.innerHTML = `
            <p style="text-align:center; font-size:18px; color:red; font-family: 'Orbitron', sans-serif;">
                ⚠️ No compraste nada todavía
            </p>
        `;
        totalHTML.textContent = "";
        return;
    }

    carrito = [];
    actualizarContador();

    contenedorCarrito.innerHTML = `
        <p style="text-align:center; font-size:18px; font-family: 'Orbitron', sans-serif;">
            🎉 ¡Compra realizada con éxito!
        </p>
    `;

    totalHTML.textContent = "";

    setTimeout(() => {
        modal.style.display = "none";
    }, 1500);
});


btnVaciar.addEventListener("click", () => {

    if (carrito.length === 0) {
        contenedorCarrito.innerHTML = `
            <p style="text-align:center; color:red; font-family: 'Orbitron', sans-serif;">
                El carrito ya está vacío
            </p>
        `;
        return;
    }

    carrito.forEach(prod => {
        const productoGlobal = productosGlobal.find(p => p.id === prod.id);
        productoGlobal.stock += prod.cantidad;
        actualizarStockVisual(prod.id);
    });

    carrito = [];
    actualizarContador();
    mostrarCarrito();
});